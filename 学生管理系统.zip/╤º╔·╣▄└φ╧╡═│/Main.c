#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include "Stu_Manage_System.h"

int main(void)
{
	password();
	key();
	return 0;
}